const int VIDEO_DEVICE_0 = 0; // zero based index of video capture device to use 

const int VIDEO_DEVICE_1 = 1; 


Capture frontCam = new capture(VIDEO_DEVICE_0); 

Capture rearCam = new capture(VIDEO_DEVICE_1); 


Gyrometer _gyrometer = new gyrometer(); 

Compass _compass = new compass(); 

void acquireImages(int imageNumber) 

{ 

    //save raw captures in memory 

   _frontImage = frontCam.Click();         

                _rearImage = rearCam.Click(); 


     //turn raw image into a readable format 

   Bitmap front = new Bitmap(_frontImage); 

                Bitmap rear = new Bitmap(_rearImage); 


     //You may need to rotate the images based on your platform 

                front.RotateFlip(RotateFlipType.RotateNoneFlipY); 

                rear.RotateFlip(RotateFlipType.RotateNoneFlipY); 


     //Save images to working directory 

                front.Save("images/" + imageNumber + "_front.jpeg");                

   rear.Save("images/" + imageNumber + "_rear.jpeg"); } 

for (int currentImage = 0; currentImage < NUM_IMAGES; currentImage++ ) 

       {  

                acquireImages(currentImage); 


                //specify interval between captures 

                Thread.Sleep(750);   

       } 

position = 0; 

while (currentImage < NUM_IMAGES) 

       { 

              position += _gyrometer.GetCurrentReading() * GYRO_SAMPLE_INTERVAL; 


          //capture image when position is at desired position +/- error 

if(position > ((currentImage*angleBetweenImages)-angleErrorTolerance) && 

       position < ((currentImage*angleBetweenImages)+angleErrorTolerance)) 

              { 

                            acquireImages(currentImage); 

                            currentImage++; 

              } 

        thread.sleep(GYRO_SAMPLE_INTERVAL);  

} 

while (currentImage < NUM_IMAGES) 

       { 

         if (currentImage == 0) 

        { 

   //initialize position at first image capture 

         startPos = _compass.GetCurrentReading().HeadingMagneticNorth; 

        } 


              position = startPos - _compass.GetCurrentReading().HeadingMagneticNorth; 


              if (position < 0) 

              { 

               //forces value to be betweeen 0 and 360 

                     position = 360 + position; 

              } 


          //capture image when position is at desired position +/- error 

if(position > ((currentImage*angleBetweenImages)-angleErrorTolerance) && 

       position < ((currentImage*angleBetweenImages)+angleErrorTolerance)) 

              { 

                            acquireImages(currentImage); 

                            currentImage++; 

              } 

string[] imgs = Directory.GetFiles("images"); 

stitch(imgs, result); 

 result.save(�images/result.jpg�); 

